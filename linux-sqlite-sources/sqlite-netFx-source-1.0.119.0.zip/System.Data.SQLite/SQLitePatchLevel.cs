/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("412ff082182b121d74a9ced16159bd0eb496deef")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2024-09-15 19:03:31 UTC")]
