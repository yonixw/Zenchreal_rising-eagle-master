/*
 * interop.h -
 *
 * Written by Joe Mistachkin.
 * Released to the public domain, use at your own risk!
 */

#ifndef INTEROP_VERSION
#define INTEROP_VERSION          "1.0.119.0"
#endif

#ifndef INTEROP_SOURCE_ID
#define INTEROP_SOURCE_ID        "412ff082182b121d74a9ced16159bd0eb496deef"
#endif

#ifndef INTEROP_SOURCE_TIMESTAMP
#define INTEROP_SOURCE_TIMESTAMP "2024-09-15 19:03:31 UTC"
#endif
